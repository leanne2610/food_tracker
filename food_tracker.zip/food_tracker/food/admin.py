from django.contrib import admin

from .models import Food, Meal
# Register your models here.

admin.site.register(Food)
admin.site.register(Meal)
